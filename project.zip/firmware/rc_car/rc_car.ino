/*
  RC Car BLE - ESP32-C3 Super Mini
  Driver: DRV8833 | Servo 90g | Lampu: depan, rem, sein kiri/kanan, hazard
  Dikompilasi untuk core esp32 v2.0.17 (API ledcSetup/ledcAttachPin)

  PAKET dari aplikasi (7 byte, write without response, ~25x/detik):
   [0] 0xA5 (header)
   [1..2] sudut servo dalam 0.1 derajat (0..1800), little-endian
   [3..4] gas -1000..1000 (int16, little-endian), + maju, - mundur
   [5] flag: bit0 lampu depan, bit1 hazard, bit2 sein kiri, bit3 sein kanan
   [6] checksum = XOR byte 0..5
*/
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

#define SERVICE_UUID "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHAR_UUID    "beb5483e-36e1-4688-b7f5-ea07361b26a8"

// ---------------- PIN (ESP32-C3 Super Mini) ----------------
const int PIN_SERVO = 1;   // sinyal servo
const int PIN_IN1   = 3;   // DRV8833 IN1 (AIN1)
const int PIN_IN2   = 4;   // DRV8833 IN2 (AIN2)
const int PIN_HEAD  = 5;   // lampu depan
const int PIN_BRAKE = 6;   // lampu rem
const int PIN_LEFT  = 7;   // sein kiri
const int PIN_RIGHT = 10;  // sein kanan

// ---------------- PENGATURAN ----------------
const int SERVO_MIN_US = 500;     // pulsa untuk 0 derajat
const int SERVO_MAX_US = 2500;    // pulsa untuk 180 derajat
const int DEADZONE     = 30;      // zona mati gas (dari 1000)
const int MOTOR_MIN    = 60;      // PWM minimum agar motor mulai berputar (0..1023)
const int ACCEL_STEP   = 40;      // kenaikan gas maks per 10 ms (halus saat tancap gas)
const int DECEL_STEP   = 150;     // penurunan gas maks per 10 ms
const unsigned long FAILSAFE_MS = 400;   // tanpa paket selama ini -> berhenti
const unsigned long BLINK_MS    = 350;   // kecepatan kedip sein

// Kanal LEDC: servo ch0 (timer0), motor ch2 & ch3 (timer1) -> frekuensi tidak bentrok
const int CH_SERVO = 0;
const int CH_IN1   = 2;
const int CH_IN2   = 3;

volatile bool     connected   = false;
volatile bool     everLinked  = false;
volatile uint32_t lastPacket  = 0;
volatile int16_t  cmdAngle10  = 900;   // 90.0 derajat
volatile int16_t  cmdThrottle = 0;
volatile uint8_t  cmdFlags    = 0;

int curThrottle = 0;

void servoWriteAngle10(int a10) {
  if (a10 < 0) a10 = 0;
  if (a10 > 1800) a10 = 1800;
  long us = SERVO_MIN_US + (long)a10 * (SERVO_MAX_US - SERVO_MIN_US) / 1800;
  uint32_t duty = (uint32_t)((uint64_t)us * 16383 / 20000);  // 14 bit, 50 Hz
  ledcWrite(CH_SERVO, duty);
}

void motorWrite(int thr) {   // thr -1000..1000
  int a = abs(thr);
  if (a <= DEADZONE) {       // rem aktif (kedua input HIGH)
    ledcWrite(CH_IN1, 1023);
    ledcWrite(CH_IN2, 1023);
    return;
  }
  int duty = map(a, DEADZONE, 1000, MOTOR_MIN, 1023);
  if (thr > 0) { ledcWrite(CH_IN1, duty); ledcWrite(CH_IN2, 0); }
  else         { ledcWrite(CH_IN1, 0);    ledcWrite(CH_IN2, duty); }
}

class ServerCB : public BLEServerCallbacks {
  void onConnect(BLEServer* s) override {
    connected = true;
    everLinked = true;
    lastPacket = millis();
  }
  void onDisconnect(BLEServer* s) override {
    connected = false;
    BLEDevice::startAdvertising();
  }
};

class CharCB : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    uint8_t* d = c->getData();
    size_t n = c->getLength();
    if (d == nullptr || n < 7 || d[0] != 0xA5) return;
    uint8_t x = 0;
    for (int i = 0; i < 6; i++) x ^= d[i];
    if (x != d[6]) return;
    cmdAngle10  = (int16_t)(d[1] | (d[2] << 8));
    cmdThrottle = (int16_t)(d[3] | (d[4] << 8));
    cmdFlags    = d[5];
    lastPacket  = millis();
  }
};

void setup() {
  pinMode(PIN_HEAD, OUTPUT);
  pinMode(PIN_BRAKE, OUTPUT);
  pinMode(PIN_LEFT, OUTPUT);
  pinMode(PIN_RIGHT, OUTPUT);
  digitalWrite(PIN_HEAD, LOW);
  digitalWrite(PIN_BRAKE, LOW);
  digitalWrite(PIN_LEFT, LOW);
  digitalWrite(PIN_RIGHT, LOW);

  ledcSetup(CH_SERVO, 50, 14);
  ledcAttachPin(PIN_SERVO, CH_SERVO);
  ledcSetup(CH_IN1, 20000, 10);
  ledcAttachPin(PIN_IN1, CH_IN1);
  ledcSetup(CH_IN2, 20000, 10);
  ledcAttachPin(PIN_IN2, CH_IN2);
  ledcWrite(CH_IN1, 0);
  ledcWrite(CH_IN2, 0);
  servoWriteAngle10(900);

  BLEDevice::init("RC-Car");
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCB());
  BLEService* svc = server->createService(SERVICE_UUID);
  BLECharacteristic* ch = svc->createCharacteristic(
      CHAR_UUID,
      BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  ch->setCallbacks(new CharCB());
  svc->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

void loop() {
  static uint32_t lastTick = 0;
  uint32_t now = millis();
  if (now - lastTick < 10) return;
  lastTick = now;

  bool linkOk = connected && (now - lastPacket < FAILSAFE_MS);
  bool lost = everLinked && !linkOk;       // pernah terhubung lalu putus / sinyal hilang
  bool blinkOn = ((now / BLINK_MS) % 2) == 0;

  int target;
  uint8_t flags;
  if (linkOk) {
    target = cmdThrottle;
    flags = cmdFlags;
    servoWriteAngle10(cmdAngle10);
  } else {
    target = 0;                  // FAILSAFE: motor berhenti, servo ditahan
    flags = lost ? 0x02 : 0x00;  // hazard berkedip selama sinyal hilang
  }

  // Penghalusan gas (kurangi lonjakan arus pada baterai 3.7 V)
  int diff = target - curThrottle;
  int step = (abs(target) > abs(curThrottle) || (target * curThrottle < 0)) ? ACCEL_STEP : DECEL_STEP;
  if (diff > step) diff = step;
  if (diff < -step) diff = -step;
  curThrottle += diff;

  if (!linkOk && !lost) {
    ledcWrite(CH_IN1, 0);        // belum pernah terhubung: motor bebas
    ledcWrite(CH_IN2, 0);
  } else {
    motorWrite(curThrottle);
  }

  bool head   = flags & 0x01;
  bool hazard = flags & 0x02;
  bool left   = flags & 0x04;
  bool right  = flags & 0x08;
  // Lampu rem: aktif jika tidak sedang maju (berhenti atau mundur) atau failsafe
  bool brake = (linkOk || lost) && !(linkOk && curThrottle > DEADZONE);

  digitalWrite(PIN_HEAD, head ? HIGH : LOW);
  digitalWrite(PIN_BRAKE, brake ? HIGH : LOW);
  digitalWrite(PIN_LEFT,  ((hazard || left)  && blinkOn) ? HIGH : LOW);
  digitalWrite(PIN_RIGHT, ((hazard || right) && blinkOn) ? HIGH : LOW);
}
