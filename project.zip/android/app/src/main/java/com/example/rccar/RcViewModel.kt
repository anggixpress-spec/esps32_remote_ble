package com.example.rccar

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class RcViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("rc", Context.MODE_PRIVATE)

    // ---- status koneksi ----
    var link by mutableStateOf(LinkState.IDLE)
        private set
    var status by mutableStateOf("Belum terhubung")
        private set

    // ---- kontrol ----
    var steer by mutableFloatStateOf(0f)       // -1 (kiri) .. +1 (kanan)
    var throttle by mutableFloatStateOf(0f)    // -1 (mundur) .. +1 (maju)
    var head by mutableStateOf(false)
    var hazard by mutableStateOf(false)
    var left by mutableStateOf(false)
    var right by mutableStateOf(false)

    // ---- pengaturan servo (disimpan) ----
    var centerDeg by mutableIntStateOf(prefs.getInt("center", 90))
    var leftDeg by mutableIntStateOf(prefs.getInt("left", 60))
    var rightDeg by mutableIntStateOf(prefs.getInt("right", 120))
    var maxSpeed by mutableIntStateOf(prefs.getInt("speed", 100))
    var useWheel by mutableStateOf(prefs.getBoolean("wheel", true))

    // Dipakai hanya saat dialog pengaturan terbuka (tes kiri/tengah/kanan)
    var testSteer by mutableStateOf<Float?>(null)

    private val ble = BleLink(app) { s, m ->
        link = s
        status = m
        if (s != LinkState.CONNECTED) throttle = 0f
    }

    init {
        viewModelScope.launch {
            while (true) {
                if (link == LinkState.CONNECTED) ble.send(buildPacket())
                delay(40)
            }
        }
    }

    fun toggleLeft() {
        left = !left
        if (left) right = false
    }

    fun toggleRight() {
        right = !right
        if (right) left = false
    }

    fun connect() = ble.start()
    fun disconnect() = ble.disconnect()
    fun neutral() { throttle = 0f }

    fun saveSettings() {
        prefs.edit()
            .putInt("center", centerDeg)
            .putInt("left", leftDeg)
            .putInt("right", rightDeg)
            .putInt("speed", maxSpeed)
            .putBoolean("wheel", useWheel)
            .apply()
    }

    private fun buildPacket(): ByteArray {
        val s = (testSteer ?: steer).coerceIn(-1f, 1f)
        val c = centerDeg.toFloat()
        val angle = if (s < 0f) c + (-s) * (leftDeg - c) else c + s * (rightDeg - c)
        val a10 = (angle * 10f).roundToInt().coerceIn(0, 1800)
        val t = (throttle.coerceIn(-1f, 1f) * maxSpeed * 10f).roundToInt().coerceIn(-1000, 1000)
        var f = 0
        if (head) f = f or 1
        if (hazard) f = f or 2
        if (left) f = f or 4
        if (right) f = f or 8

        val b = ByteArray(7)
        b[0] = 0xA5.toByte()
        b[1] = (a10 and 0xFF).toByte()
        b[2] = ((a10 shr 8) and 0xFF).toByte()
        b[3] = (t and 0xFF).toByte()
        b[4] = ((t shr 8) and 0xFF).toByte()
        b[5] = f.toByte()
        var x = 0
        for (i in 0..5) x = x xor (b[i].toInt() and 0xFF)
        b[6] = x.toByte()
        return b
    }

    override fun onCleared() {
        ble.disconnect()
        super.onCleared()
    }
}
