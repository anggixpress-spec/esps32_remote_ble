package com.example.rccar

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.UUID

enum class LinkState { IDLE, SCANNING, CONNECTING, CONNECTED }

val SERVICE_UUID: UUID = UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b")
val CHAR_UUID: UUID = UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8")

@SuppressLint("MissingPermission")
class BleLink(
    private val ctx: Context,
    private val onState: (LinkState, String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var ch: BluetoothGattCharacteristic? = null
    @Volatile private var ready = false
    private var scanning = false

    private fun post(s: LinkState, msg: String) {
        main.post { onState(s, msg) }
    }

    private val scanTimeout = Runnable {
        if (scanning) {
            stopScan()
            post(LinkState.IDLE, "RC-Car tidak ditemukan. Pastikan mobil menyala.")
        }
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!scanning) return
            stopScan()
            connect(result.device)
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            post(LinkState.IDLE, "Scan gagal (kode $errorCode)")
        }
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                main.postDelayed({ if (gatt === g) g.discoverServices() }, 400)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ready = false
                ch = null
                try { g.close() } catch (e: Exception) { }
                if (gatt === g) gatt = null
                post(LinkState.IDLE, "Terputus")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val c = g.getService(SERVICE_UUID)?.getCharacteristic(CHAR_UUID)
            if (status == BluetoothGatt.GATT_SUCCESS && c != null) {
                ch = c
                ready = true
                post(LinkState.CONNECTED, "Terhubung ke RC-Car")
            } else {
                post(LinkState.IDLE, "Layanan RC tidak ditemukan")
                disconnect()
            }
        }
    }

    fun start() {
        val a = adapter
        if (a == null || !a.isEnabled) {
            post(LinkState.IDLE, "Nyalakan Bluetooth lalu coba lagi")
            return
        }
        val scanner = a.bluetoothLeScanner
        if (scanner == null) {
            post(LinkState.IDLE, "Scanner Bluetooth tidak tersedia")
            return
        }
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanning = true
        post(LinkState.SCANNING, "Mencari RC-Car...")
        try {
            scanner.startScan(listOf(filter), settings, scanCb)
        } catch (e: Exception) {
            scanning = false
            post(LinkState.IDLE, "Scan gagal: ${e.message}")
            return
        }
        main.postDelayed(scanTimeout, 15000)
    }

    private fun stopScan() {
        main.removeCallbacks(scanTimeout)
        if (scanning) {
            scanning = false
            try { adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (e: Exception) { }
        }
    }

    private fun connect(dev: BluetoothDevice) {
        post(LinkState.CONNECTING, "Menyambung...")
        gatt = dev.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        stopScan()
        ready = false
        val g = gatt
        if (g == null) {
            post(LinkState.IDLE, "Terputus")
            return
        }
        try { g.disconnect() } catch (e: Exception) { }
        main.postDelayed({
            if (gatt === g) {
                try { g.close() } catch (e: Exception) { }
                gatt = null
                ch = null
                post(LinkState.IDLE, "Terputus")
            }
        }, 1500)
    }

    @Suppress("DEPRECATION")
    fun send(data: ByteArray): Boolean {
        val g = gatt ?: return false
        val c = ch ?: return false
        if (!ready) return false
        return try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(
                    c, data, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                ) == BluetoothStatusCodes.SUCCESS
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = data
                g.writeCharacteristic(c)
            }
        } catch (e: Exception) {
            false
        }
    }
}
