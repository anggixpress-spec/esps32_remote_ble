package com.example.rccar

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private val vm: RcViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                RcScreen(vm)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        vm.neutral()   // gas nol jika aplikasi ke latar belakang
    }
}

private val ColBg = Color(0xFF0F1318)
private val ColOff = Color(0xFF2A3139)
private val ColText = Color(0xFFB0BAC5)

@Composable
fun RcScreen(vm: RcViewModel) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }

    val perms = if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) vm.connect()
        else Toast.makeText(ctx, "Izin Bluetooth diperlukan", Toast.LENGTH_LONG).show()
    }
    val onConnect: () -> Unit = {
        if (vm.link != LinkState.IDLE) {
            vm.disconnect()
        } else {
            val need = perms.filter {
                ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED
            }
            if (need.isEmpty()) vm.connect() else launcher.launch(need.toTypedArray())
        }
    }

    Surface(color = ColBg, modifier = Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---- KIRI: setir / slider ----
            Box(Modifier.weight(1f).fillMaxHeight()) {
                SteeringArea(vm)
            }

            // ---- TENGAH: tombol-tombol ----
            Column(
                Modifier.weight(1.2f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        vm.status,
                        color = ColText,
                        fontSize = 13.sp,
                        maxLines = 2,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onConnect,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) { Text(if (vm.link == LinkState.IDLE) "Hubungkan" else "Putus") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { showSettings = true },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) { Text("⚙ Servo") }
                }

                ToggleBtn(
                    "LAMPU DEPAN", vm.head, Color(0xFFFFE066),
                    Modifier.fillMaxWidth(0.85f).height(56.dp)
                ) { vm.head = !vm.head }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ToggleBtn(
                        "◀ SEIN", vm.left, Color(0xFFFFB300),
                        Modifier.weight(1f).height(56.dp)
                    ) { vm.toggleLeft() }
                    ToggleBtn(
                        "HAZARD", vm.hazard, Color(0xFFFF5252),
                        Modifier.weight(1.3f).height(56.dp)
                    ) { vm.hazard = !vm.hazard }
                    ToggleBtn(
                        "SEIN ▶", vm.right, Color(0xFFFFB300),
                        Modifier.weight(1f).height(56.dp)
                    ) { vm.toggleRight() }
                }

                val braking = vm.throttle <= 0.03f
                Box(
                    Modifier
                        .fillMaxWidth(0.85f)
                        .height(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (braking) Color(0xFFD32F2F) else Color(0xFF3A1D1D)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "LAMPU REM",
                        color = if (braking) Color.White else Color(0xFF7A5555),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            // ---- KANAN: slider gas ----
            Box(
                Modifier.weight(0.6f).fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                ThrottleStick(vm, Modifier.width(110.dp).fillMaxHeight(0.96f))
            }
        }
    }

    if (showSettings) {
        SettingsDialog(vm) { showSettings = false }
    }
}

@Composable
fun ToggleBtn(
    label: String,
    on: Boolean,
    onColor: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (on) onColor else ColOff)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (on) Color.Black else ColText,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

// ======================= SETIR / SLIDER KIRI =======================

private const val WHEEL_MAX_DEG = 135f

@Composable
fun SteeringArea(vm: RcViewModel) {
    var pressed by remember { mutableStateOf(false) }

    // Kembali ke tengah saat dilepas
    LaunchedEffect(pressed) {
        if (!pressed) {
            animate(
                vm.steer, 0f,
                animationSpec = spring(dampingRatio = 0.75f, stiffness = 350f)
            ) { v, _ -> vm.steer = v.coerceIn(-1f, 1f) }
            vm.steer = 0f
        }
    }

    if (vm.useWheel) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val s = minOf(maxWidth, maxHeight) * 0.95f
            Canvas(
                Modifier
                    .size(s)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            pressed = true
                            val cx = size.width / 2f
                            val cy = size.height / 2f
                            var prev = atan2(down.position.y - cy, down.position.x - cx)
                            down.consume()
                            while (true) {
                                val ev = awaitPointerEvent()
                                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                if (!c.pressed) break
                                val a = atan2(c.position.y - cy, c.position.x - cx)
                                var d = Math.toDegrees((a - prev).toDouble()).toFloat()
                                if (d > 180f) d -= 360f
                                if (d < -180f) d += 360f
                                prev = a
                                val rot = (vm.steer * WHEEL_MAX_DEG + d)
                                    .coerceIn(-WHEEL_MAX_DEG, WHEEL_MAX_DEG)
                                vm.steer = rot / WHEEL_MAX_DEG
                                c.consume()
                            }
                            pressed = false
                        }
                    }
            ) { drawWheel(vm.steer) }
        }
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            pressed = true
                            val kr = size.height * 0.42f
                            val half = size.width / 2f - kr
                            fun calc(x: Float) = ((x - size.width / 2f) / half).coerceIn(-1f, 1f)
                            vm.steer = calc(down.position.x)
                            down.consume()
                            while (true) {
                                val ev = awaitPointerEvent()
                                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                if (!c.pressed) break
                                vm.steer = calc(c.position.x)
                                c.consume()
                            }
                            pressed = false
                        }
                    }
            ) { drawHSlider(vm.steer) }
        }
    }
}

private fun DrawScope.drawWheel(steer: Float) {
    val r = size.minDimension / 2f
    val c = center
    rotate(degrees = steer * WHEEL_MAX_DEG, pivot = c) {
        val rim = Color(0xFF3A444F)
        drawCircle(rim, radius = r * 0.9f, center = c, style = Stroke(width = r * 0.16f))
        for (deg in intArrayOf(0, 90, 180)) {
            val rad = Math.toRadians(deg.toDouble())
            val end = Offset(
                c.x + (r * 0.82f * cos(rad)).toFloat(),
                c.y + (r * 0.82f * sin(rad)).toFloat()
            )
            drawLine(rim, c, end, strokeWidth = r * 0.12f, cap = StrokeCap.Round)
        }
        drawCircle(Color(0xFF59C2FF), radius = r * 0.2f, center = c)
        drawLine(
            Color(0xFFFF5252),
            Offset(c.x, c.y - r * 0.98f),
            Offset(c.x, c.y - r * 0.78f),
            strokeWidth = r * 0.09f,
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawHSlider(v: Float) {
    val w = size.width
    val h = size.height
    val trackH = h * 0.35f
    val top = (h - trackH) / 2f
    val kr = h * 0.42f
    val cx = w / 2f
    val kx = cx + v * (w / 2f - kr)
    drawRoundRect(ColOff, Offset(0f, top), Size(w, trackH), CornerRadius(trackH / 2f))
    drawRoundRect(
        Color(0xFF59C2FF),
        Offset(min(cx, kx), top),
        Size(abs(kx - cx), trackH),
        CornerRadius(trackH / 2f)
    )
    drawLine(Color(0xFF6B7683), Offset(cx, top - 6f), Offset(cx, top + trackH + 6f), strokeWidth = 4f)
    drawCircle(Color(0xFFE8EEF4), radius = kr, center = Offset(kx, h / 2f))
}

// ======================= SLIDER GAS KANAN =======================

@Composable
fun ThrottleStick(vm: RcViewModel, modifier: Modifier) {
    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val kr = size.width * 0.42f
                val half = size.height / 2f - kr
                fun calc(y: Float) = ((size.height / 2f - y) / half).coerceIn(-1f, 1f)
                vm.throttle = calc(down.position.y)
                down.consume()
                while (true) {
                    val ev = awaitPointerEvent()
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!c.pressed) break
                    vm.throttle = calc(c.position.y)
                    c.consume()
                }
                vm.throttle = 0f   // lepas = langsung nol
            }
        }
    ) {
        val w = size.width
        val h = size.height
        val trackW = w * 0.42f
        val left = (w - trackW) / 2f
        val kr = w * 0.42f
        val cy = h / 2f
        val ky = cy - vm.throttle * (h / 2f - kr)
        drawRoundRect(ColOff, Offset(left, 0f), Size(trackW, h), CornerRadius(trackW / 2f))
        val fillColor = if (vm.throttle >= 0f) Color(0xFF4CD964) else Color(0xFFFF9F0A)
        drawRoundRect(
            fillColor,
            Offset(left, min(cy, ky)),
            Size(trackW, abs(ky - cy)),
            CornerRadius(trackW / 2f)
        )
        drawLine(Color(0xFF6B7683), Offset(left - 10f, cy), Offset(left + trackW + 10f, cy), strokeWidth = 4f)
        drawCircle(Color(0xFFE8EEF4), radius = kr, center = Offset(w / 2f, ky))
    }
}

// ======================= PENGATURAN SERVO =======================

@Composable
fun SettingsDialog(vm: RcViewModel, onClose: () -> Unit) {
    val close = {
        vm.testSteer = null
        vm.saveSettings()
        onClose()
    }
    AlertDialog(
        onDismissRequest = close,
        confirmButton = { TextButton(onClick = close) { Text("Simpan & tutup") } },
        title = { Text("Pengaturan servo & kontrol") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NumRow("Sudut tengah (°)", vm.centerDeg, 0..180) { vm.centerDeg = it }
                NumRow("Sudut kiri maks (°)", vm.leftDeg, 0..180) { vm.leftDeg = it }
                NumRow("Sudut kanan maks (°)", vm.rightDeg, 0..180) { vm.rightDeg = it }
                NumRow("Kecepatan maks (%)", vm.maxSpeed, 1..100) { vm.maxSpeed = it }
                Text(
                    "Tes servo (harus terhubung):",
                    fontSize = 12.sp,
                    color = ColText
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.testSteer = -1f }) { Text("Kiri") }
                    OutlinedButton(onClick = { vm.testSteer = 0f }) { Text("Tengah") }
                    OutlinedButton(onClick = { vm.testSteer = 1f }) { Text("Kanan") }
                }
                Text(
                    "Jika arah setir terbalik, tukar angka kiri dan kanan.",
                    fontSize = 12.sp,
                    color = ColText
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (vm.useWheel) "Kontrol kiri: Setir" else "Kontrol kiri: Slider",
                        Modifier.weight(1f)
                    )
                    Switch(checked = vm.useWheel, onCheckedChange = { vm.useWheel = it })
                }
            }
        }
    )
}

@Composable
fun NumRow(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        OutlinedButton(
            onClick = { onChange((value - 1).coerceIn(range)) },
            contentPadding = PaddingValues(0.dp),
            modifier = Modifier.size(40.dp)
        ) { Text("−") }
        OutlinedTextField(
            value = text,
            onValueChange = { t ->
                val d = t.filter { it.isDigit() }.take(3)
                text = d
                val n = d.toIntOrNull()
                if (n != null) {
                    val cl = n.coerceIn(range)
                    onChange(cl)
                    if (cl != n) text = cl.toString()
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = TextStyle(textAlign = TextAlign.Center, fontSize = 16.sp),
            modifier = Modifier.width(84.dp)
        )
        OutlinedButton(
            onClick = { onChange((value + 1).coerceIn(range)) },
            contentPadding = PaddingValues(0.dp),
            modifier = Modifier.size(40.dp)
        ) { Text("+") }
    }
}
